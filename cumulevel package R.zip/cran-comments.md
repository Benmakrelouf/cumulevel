## Test environments
* Ubuntu 24.04, R 4.3.3 (local)

## R CMD check results
0 errors | 0 warnings | 0 notes

The two items reported locally are environmental and do not arise on the
CRAN check machines:

* a WARNING from `Sys.setlocale("LC_CTYPE", "en_US.UTF-8")` — the container
  used for development has no en_US.UTF-8 locale;
* a NOTE that the suggested packages ranger, testthat, knitr and rmarkdown
  are unavailable in that container.

All substantive checks pass: Rd files, Rd cross-references, Rd \usage
sections, code/documentation mismatches, S3 method registration, undocumented
arguments, dependencies in R code, and all examples.

## Notes for the reviewer

* The two shipped data sets are synthetic. The survey file underlying the
  first published application cannot be redistributed under the access
  conditions of the archive that holds it; the second is public domain but
  large, and is downloaded by a script in inst/scripts/. Both are documented
  as synthetic in their help pages.
* Examples run in well under 5 seconds each. The Monte Carlo sensitivity
  layer is called with small S and B in examples.
* This is a first submission.
